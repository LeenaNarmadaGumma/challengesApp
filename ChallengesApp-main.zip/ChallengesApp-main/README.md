# ChallengesApp
A simple Spring Boot project to learn AWS deployment
